package com.example.ejemplo_1;

import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    //Importe las clases de los objetos que va a utilizar
    private EditText In1,In2, Re;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Inicie las clases y asigne el id correspondiente.
        In1=(EditText)findViewById(R.id.Entrada1);
        In2=(EditText)findViewById(R.id.Entrada2);
        Re=(EditText)findViewById(R.id.Resultado);
        //**************************************//
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    //Metodo a asignar al boton
    public void Funcion_clic(View view){
        //Leer de un campo de texto
        String N1=In1.getText().toString();
        String N2=In2.getText().toString();
        //Convetir texto a numero
        double Valor1=Double.parseDouble(N1);
        double Valor2=Double.parseDouble(N2);
        double Valor3=Valor1+Valor2;
        //Convetir numero a String
        String Salida=String.valueOf(Valor3);
        //Publicar en campo de salida
        Re.setText(Salida);
    }
}
