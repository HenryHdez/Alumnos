package com.example.ejemplo_2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.SeekBar;

public class MainActivity extends AppCompatActivity {
    //Cree las clases para llamar a los objetos
    private EditText In1;
    private SeekBar S1;
    private ProgressBar P1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Enlace los objetos
        In1=(EditText) findViewById(R.id.editText);
        S1=(SeekBar) findViewById(R.id.seekBar);
        P1=(ProgressBar) findViewById(R.id.progressBar);
        //Cree un oyente que se active al activar la barra
        S1.setOnSeekBarChangeListener(
                //Estructura de un oyente (Creada por defecto)
                new SeekBar.OnSeekBarChangeListener() {
                    @Override
                    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                        In1.setText("Valor: "+S1.getProgress()+"%");
                        P1.setProgress(S1.getProgress());
                    }

                    @Override
                    public void onStartTrackingTouch(SeekBar seekBar) {

                    }

                    @Override
                    public void onStopTrackingTouch(SeekBar seekBar) {

                    }
                }
        );
    }

}
