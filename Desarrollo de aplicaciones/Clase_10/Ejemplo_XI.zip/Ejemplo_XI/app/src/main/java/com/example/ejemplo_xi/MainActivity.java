package com.example.ejemplo_xi;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import static android.Manifest.*;

public class MainActivity extends AppCompatActivity {
    Button Activar_GPS;
    EditText Longitudtv, Latitudtv, Altitudtv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Longitudtv=(EditText)findViewById(R.id.editText);
        Latitudtv=(EditText)findViewById(R.id.editText2);
        Altitudtv=(EditText)findViewById(R.id.editText3);
        Activar_GPS=(Button)findViewById(R.id.button);

        //Está variable almacena el valor del estado del permiso para acceder al sensor
        //1=usuario autoriza 0= no autoriza
        int Verificar_Permiso = ContextCompat.checkSelfPermission(
                this, permission.ACCESS_FINE_LOCATION);
        //Está estructura en segundo plano activa el cuadro de dialogo para que
        //el usuario autorice el uso del GPS
        if(Verificar_Permiso == PackageManager.PERMISSION_DENIED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(
                    this, permission.ACCESS_FINE_LOCATION)) {

            }
            else {
                ActivityCompat.requestPermissions(this,
                        new String[]{permission.ACCESS_FINE_LOCATION}, 1);
            }
        }
        //Asigne un oyente al botón para que se active cada vez que lo pulsen
        Activar_GPS.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                //Dentro de la función se crea un oyente para el GPS
                LocationManager locationManager = (LocationManager)
                        MainActivity.this.getSystemService(Context.LOCATION_SERVICE);
                LocationListener locationListener = new LocationListener() {
                    //Se usan las funciones definidas por defecto
                    @Override
                    public void onLocationChanged(Location location) {
                        Longitudtv.setText(" "+location.getLongitude());
                        Latitudtv.setText(" "+location.getLatitude());
                        Altitudtv.setText(" "+location.getAltitude());
                    }
                    @Override
                    public void onStatusChanged(String provider, int status, Bundle extras) {}
                    @Override
                    public void onProviderEnabled(String provider) {}
                    @Override
                    public void onProviderDisabled(String provider) {}
                };
                int Estado_permiso = ContextCompat.checkSelfPermission(
                        MainActivity.this, Manifest.permission.ACCESS_FINE_LOCATION);
                locationManager.requestLocationUpdates(
                        LocationManager.NETWORK_PROVIDER,0,0,locationListener);
            }
        });

    }
}
