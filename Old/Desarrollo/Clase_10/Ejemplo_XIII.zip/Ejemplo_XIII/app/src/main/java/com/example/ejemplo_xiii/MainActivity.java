package com.example.ejemplo_xiii;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.FileUtils;
import android.view.View;
import android.widget.EditText;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

public class MainActivity extends AppCompatActivity {
    EditText Tx1,Tx2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Tx1=(EditText)findViewById(R.id.editText);
        Tx2=(EditText)findViewById(R.id.editText2);
    }

    public void Escribir_archivo(View view){
        File nuevaCarpeta=null;
        OutputStreamWriter Salida = null;
        nuevaCarpeta = new File( //Está función permite crear una carpeta
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM),
                "miCarpeta");
        nuevaCarpeta.mkdir();
        try{//Estructura para intentar acceder al archivo
            File Archivo; //Está estructura permite crear un archivo de texto
            Archivo = new File(nuevaCarpeta,"Ejemplo.txt");
            Archivo.createNewFile();
            Salida=new OutputStreamWriter(new FileOutputStream(Archivo));
            //digite lo que quiera escribir en el arhivo.
            Salida.write("" + Tx1.getText()); //Esta forma intenta escribir el archivo
            //Recuerde cerrar el archivo
            Salida.close();
        }
        catch (IOException e){ //Si no se puede acceder al archivo se publica este aviso
            Tx2.setText(""+e);
        }
    }

    public void Leer_archivo(View view){ //Estructura encargada de abrir un cuadro de dialogo abrir.
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType("text/plain");
        startActivityForResult(Intent.createChooser(intent, "Escoja Archivo."), 1);
    }
    @ Override //OnactivityResult es una función que se activa al cerrar el cuadro de dialogo
    public void onActivityResult(int requestCode, int resultCode, Intent resultData) {
        if (requestCode == 1 && resultCode == Activity.RESULT_OK) { //Si seleccione algo
            Uri uri = null;
            if (resultData != null) {
                uri = resultData.getData();             //Lea la información de lo que seleccione
                String Directorio = uri.getPath();
                try{//Estructura para leer un archivo
                    File Archivo;
                    Archivo = new File(Directorio); //Cree un buffer
                    BufferedReader Buffer=new BufferedReader(
                            new InputStreamReader(getContentResolver().openInputStream(resultData.getData())));
                    String Texto=Buffer.readLine(); //Leer linea a linea el contenido del archivo
                    Tx2.setText(Texto);
                    Buffer.close(); //Cerrar buffer de entrada
                }
                catch (IOException e){Tx2.setText(""+e);}
            }
        }
    }

}
