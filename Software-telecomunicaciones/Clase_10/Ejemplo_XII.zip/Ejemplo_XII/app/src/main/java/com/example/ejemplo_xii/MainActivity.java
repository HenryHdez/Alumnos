package com.example.ejemplo_xii;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;

public class MainActivity extends AppCompatActivity {
    EditText tv1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tv1=(EditText)findViewById(R.id.editText);
    }

    public void Seleccionar_red(View view){
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_TEXT, "Mensaje de prueba 1 = "+tv1.getText());
        startActivity(Intent.createChooser(intent, "Compartir con:"));
    }

    public void Usar_Facebook(View view){
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_TEXT, "Mensaje de prueba 1 = "+tv1.getText());
        intent.setPackage("com.facebook.katana");
        startActivity(intent);
    }

    public void Usar_Twiter(View view){
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_TEXT, "Mensaje de prueba 1 = "+tv1.getText());
        intent.setPackage("com.twitter.android");
        startActivity(intent);
    }

    public void Usar_Whatsapp(View view){
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_TEXT, "Mensaje de prueba 1 = "+tv1.getText());
        intent.setPackage("com.whatsapp");
        startActivity(intent);
    }
}
