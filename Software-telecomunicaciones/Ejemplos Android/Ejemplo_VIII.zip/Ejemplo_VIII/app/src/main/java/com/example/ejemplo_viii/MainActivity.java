package com.example.ejemplo_viii;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView Tx1;
    TextView Tx2;
    TextView Tx3;
    TextView Tx4;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        RelativeLayout Lauyout=(RelativeLayout) findViewById(R.id.fondo);
        Tx1 = (TextView) findViewById(R.id.textView);
        Tx2 = (TextView) findViewById(R.id.textView2);
        Tx3 = (TextView) findViewById(R.id.textView3);
        Tx4 = (TextView) findViewById(R.id.textView4);
        Tx4.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event){
                float x = event.getX();
                float y = event.getY();
                Tx1.setText(Double.toString(x));
                Tx2.setText(Double.toString(y));
                switch (event.getAction()){
                    case MotionEvent.ACTION_DOWN:
                        Tx3.setText("Pulso");
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        Tx3.setText("Arrastrando");
                        break;
                    case MotionEvent.ACTION_UP:
                        Tx3.setText("Solto");
                        break;
                    default:
                        return false;
                }
                return true;
            }
        });
    }
}
