package com.example.ejemplo_xiv;

//Librerías necesarias para el desarrollo de la APP
import androidx.appcompat.app.AppCompatActivity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.os.Bundle;
import android.os.ParcelUuid;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import java.io.IOException;
import java.util.Set;

public class MainActivity extends AppCompatActivity {
    //Definición de variables globales.
    EditText Entrada, Salida, Estado;
    ListView Dispositivos;
    boolean Bandera=false;
    //Variables propias de la clase bluetooth
    BluetoothAdapter Adaptador;
    Set<BluetoothDevice> dispositivos_emparejados;
    BluetoothSocket Socket;
    //Está es una definición de lista en java, en este caso es un arreglo vacio
    //de tipo ArrayAdapter. Cuya función es almacenar los dispositivos emparejados
    //con el celular.
    ArrayAdapter<String> Adaptador_dispositivos_emparejados;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //Constructor e inicio de la interfaz grafica.
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Enlace de las variables de la interfaz con la clase
        Estado   =(EditText)findViewById(R.id.editText);
        Salida   =(EditText)findViewById(R.id.editText2);
        Entrada  =(EditText)findViewById(R.id.editText3);
        //Definición de una lista en android studio.
        Dispositivos=(ListView)findViewById(R.id.Dispositivos_Disponibles);
        //Se asigna el tipo de lista
        Adaptador_dispositivos_emparejados = new ArrayAdapter<String>(this,
                R.layout.support_simple_spinner_dropdown_item);
        //Se asigna la variable que almacena los elementos de la lista
        Dispositivos.setAdapter(Adaptador_dispositivos_emparejados);
        //Esta el la función oyente del listview que se encarga de hacer algo cuando selecciono un
        //elemento de la lista.
        Dispositivos.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            //Definición de la clase por defecto
            public void onItemClick(AdapterView<?> parent, View view, int position, long id){
                int item = position; //esta variable se actualiza al seleccionar algo de la lista
                Adaptador.cancelDiscovery(); //Para actualización de los dispositivos disponibles.
                //Leer elemento seleccionado
                String itemval = (String)Dispositivos.getItemAtPosition(position);
                //Extraer MAC
                String direccion = itemval.substring(itemval.length() - 17);
                Estado.setText("Conectado a:"+direccion);
                //Estas variables permiten definir el dispositivo al cual me conecto.
                BluetoothDevice Dispositivo_conectado=Adaptador.getRemoteDevice(direccion);
                //UUID es un numero de identificación propio del celular por lo tanto se debe leer.
                ParcelUuid[] UUIDS = Dispositivo_conectado.getUuids();
                //Intenta conectarse al dispositivo
                try {
                    Socket=Dispositivo_conectado.
                            createInsecureRfcommSocketToServiceRecord(UUIDS[0].getUuid());
                    Socket.connect();
                }
                catch (IOException e) {
                    Estado.setText("No conectado");
                }
            }
        });
        //Inicialización del Bluetooth (BT).
        Adaptador=BluetoothAdapter.getDefaultAdapter();
        if(Adaptador==null){Bandera=false; Estado.setText("El dispositivo no implementa BT");}
        else{Bandera=true; Estado.setText(Adaptador.getName());}
    }

    public void Encender_Bluetooth(View view){
        if(Bandera){
            if(Adaptador.isEnabled()==false){
                //La función Intent se usa para acceder al BT
                Intent Habilitar_BT=new Intent(Adaptador.ACTION_REQUEST_ENABLE);
                //La función startActivityForResult se usa para iniciar la
                //actividad solicitada en este caso encender el BT.
                startActivityForResult(Habilitar_BT, 0);
                Estado.setText("BT encendido.");
            }
        }
        else{Estado.setText("No se pudó encender el BT");}
    }

    public void Dispositivos_emparejados(View view){
        //Esta función permite actualizar el listview
        if(Bandera){
            if(Adaptador.isDiscovering()==false){
                Adaptador.startDiscovery();
                //Esta función lee los dispositivos emparejados con el celular.
                dispositivos_emparejados = Adaptador.getBondedDevices();
                //Esta es la forma de actualizar la lista del listview
                if (dispositivos_emparejados.size() > 0) {
                    //Esta forma de realizar el for le permite a android recorrer el vector
                    //dispositivos_emparejados en pasos de 1 y asignar ese valor a dispositivo
                    for (BluetoothDevice dispositivo : dispositivos_emparejados) {
                        Adaptador_dispositivos_emparejados.
                                add(dispositivo.getName() + "\n" + dispositivo.getAddress());
                    }
                }
            }
            else{
                Estado.setText("Reinicie la detección de dispositivos");
                Adaptador.cancelDiscovery();
            }
        }
    }

    public void Apagar_Bluetooth(View view){
        if(Bandera){
            //Apagar BT.
            Adaptador.disable();
            Estado.setText("BT apagado.");
        }
    }

    public void Enviar(View view){
        //Leer el cuadro de texto y enviar a traves del socket
        if(Bandera){
            try {
                String Texto = Entrada.getText().toString();
                //Antes de enviar se debe codificar la información en bytes
                Socket.getOutputStream().write(Texto.getBytes());
            } catch (IOException e) {
                Estado.setText("No puede enviar dato");
            }
        }
    }

    public void Leer(View view){
        //Esta función permite leer la información que llega byte a byte. Sin embargo, hay formas
        // más optimas para leer palabras o tramos enteros, tales como; temporizadores, contadores o
        //hilos. Tenga en cuenta que el programa espera hasta que haya al menos un dato en el buffer
        if(Bandera){
            try {
                String Texto = ""+((char)Socket.getInputStream().read());
                Salida.setText(Texto);
            } catch (IOException e) {
                Estado.setText("No hay datos en el buffer");
            }
        }
    }

}

