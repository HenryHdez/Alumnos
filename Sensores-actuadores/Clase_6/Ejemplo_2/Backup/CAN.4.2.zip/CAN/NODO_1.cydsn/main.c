/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"

uint8 dato_enviado=0;
uint8 dato_recibido=0;

int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */
    CAN_Start();
    LCD_Start();
    LCD_Position(0,0);
    LCD_PrintString("NODO_1");
    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
    for(;;)
    {
        /* Place your application code here. */
        dato_enviado++;
        CAN_SendMsg0();
        CyDelay(1000);
        CAN_ReceiveMsg0();
        LCD_Position(1,0);
        LCD_PrintNumber(dato_enviado);
        LCD_Position(1,8);
        LCD_PrintNumber(dato_recibido);
        }
}

/* [] END OF FILE */
